from bs4 import BeautifulSoup
import requests
import re
import bs4
import json
import boto3

urls = []



HEADERS = {
'authority': 'www.amazon.com',
'pragma': 'no-cache',
'cache-control': 'no-cache',
'dnt': '1',
'upgrade-insecure-requests': '1',
'user-agent': 'Mozilla/5.0 (X11; CrOS x86_64 8172.45.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.64 Safari/537.36',
'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
'sec-fetch-site': 'none',
'sec-fetch-mode': 'navigate',
'sec-fetch-dest': 'document',
'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
}

def clean_by_regex(text):
    # trim leading white space
    text = re.sub(r'^\s+', '', text)
    
    # trim tailing white space
    text = re.sub(r'\s+$', '', text)
    
    # strip line breaks
    text = re.sub(r'\r\n|\n|\r', '', text)
    
    return text

def products_url_crawler(page_num):
    url = f'https://www.amazon.com/s?i=pets&rh=n%3A2619533011&fs=true&page={page_num}'
    
   
    while True:
        try:
            page = requests.get(url, headers = HEADERS)
            break
        except:
            continue
    soup = BeautifulSoup(page.content, 'html.parser')
    products = soup.find_all('h2')
    
    for item in products:
        product_url = item.find('a')['href']
        if 'slredirect' not in product_url: 
            print(product_url)
            urls.append(f"https://www.amazon.com{product_url}")
            


def get_product_info(url):

    data = {'title':[], 'price':[], 'num_rating':[], 'date':[], 'star':[], 'text':[], 'exclamation':[], 'question':[], 'great':[]}
        
    
    url_parts = url.split('/')
    product_name = url_parts[3]
    product_id = url_parts[5]
    review_prefix = f'https://www.amazon.com/{product_name}/product-review/{product_id}/'
    review_suffix = 'ref=cm_cr_dp_d_show_all_btm?ie=UTF8&reviewerType=all_reviews'
    reviews_url = f'{review_prefix}{review_suffix}'
    
    
    while True:
        try:
            response = requests.get(url, headers=HEADERS)
            break
        except:
            continue
    
    soup = BeautifulSoup(response.text, 'html.parser')
    
    
    # get the title of the product
    try:
        title = soup.find('span', {'id': 'productTitle'}).string
        title = clean_by_regex(title)
    except:
        title = 'none'

    # get price of the product
    try:
        price_whole = soup.find('span', {'class':'a-price-whole'}).text
        price_fraction = soup.find('span', {'class':'a-price-fraction'}).text
    
        price = f'{price_whole}{price_fraction}'
    except:
        price = 'none'
    
    try:
        num_rating = soup.find('span', {'id':'acrCustomerReviewText'}).text
    except:
        num_rating = 'none'
    
    review_num = 0
    while review_num <= 100:
        # get reviews
        while True:
            try:
                reviews_response = requests.get(reviews_url, headers=HEADERS)
                break
            except:
                continue

        reviews_soup = BeautifulSoup(reviews_response.text, 'html.parser')

        reviews = reviews_soup.find_all('div', {'class': 'a-section review aok-relative'})

        for review in reviews:
            # get star
            star = review.find('a', {'class': 'a-link-normal'}).get_text()
            star = clean_by_regex(star)

            # get review text
            text = review.find('div', {'class': 'a-row a-spacing-small review-data'}).get_text()
            text = clean_by_regex(text)
            
            date = review.find('span', {'data-hook':'review-date'}).text

            # extract sentences that:
            # 1) end with exclamation mark(s)
            # 2) end with question mark(s)
            # 3) contain the word great/Great
            exclamation = ""
            question = ""
            great = ""
            exclamations = re.findall('([^.?!]*)\\!', text)
            for a_exclamation in exclamations:
                exclamation = exclamation + a_exclamation + "!"
            questions = re.findall('([^.?!]*)\\?', text)
            for a_question in questions:
                question = question + a_question + "?"
            greats = re.findall('[^.]*(?i)great [^.]*\.', text)
            for a_great in greats:
                great = great + a_great    

            data['title'].append(title)
            data['price'].append(price)
            data['num_rating'].append(num_rating) 
            data['date'].append(date)
            data['star'].append(star)
            data['text'].append(text)
            data['exclamation'].append(exclamation)
            data['question'].append(question)
            data['great'].append(great)
            
        try:
            next_url = reviews_soup.find('li',{'class':'a-last'}).find('a')['href']
            reviews_url = f'https://www.amazon.com{next_url}'
            continue
        except:
            break

        review_num += 1

    s3 = boto3.resource('s3')

    file_name = f'{title}.json'
    
    s3_object = s3.Object('macss30123amazondata', file_name)
    s3_object.put(Body=bytes(json.dumps(data).encode('UTF-8')))

    print("JSON is saved in S3 bucket.")
    


def product_url_loop(page_num_list):
    for page_num in page_num_list:
        products_url_crawler(page_num)
        


def product_info_loop(url_list):
    for url in url_list:
        print(url)
        get_product_info(url)
    


def lambda_handler(event, context):
    
    page_range = event['page']

    print('get_urls')

    product_url_loop(page_range)
    
    print('get_reviews')

    product_info_loop(urls)

    return


